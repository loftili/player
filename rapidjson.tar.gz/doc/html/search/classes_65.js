var searchData=
[
  ['encoding',['Encoding',['../classrapidjson_1_1_encoding.html',1,'rapidjson']]]
];
